## Changelog

### [1.0.0] - 
- plugin migratorから分岐してクリップボード連携に集中していく

### [0.2.0] - 2024-05-31
- opensource version (MIT License)
- change social account

### [0.1.0] - 2023-11-18
- Initial release
    - https://chromewebstore.google.com/detail/kintonepluginmigrator/pndmdhhanlckeimjahjfijelpkbgoeac


